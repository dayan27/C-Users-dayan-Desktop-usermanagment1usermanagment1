package com.example.usermanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import com.example.usermanagment.DatabaseHelper;
import com.example.usermanagment.R;
import com.example.usermanagment.SharedPreference;

public class MyDetail extends AppCompatActivity {

     SharedPreference sharedPreference;
    DatabaseHelper databaseHelper;

    TextView fullName,userName,email,phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_detail);
        sharedPreference =new SharedPreference(this);
        databaseHelper=new DatabaseHelper(this);
        fullName=findViewById(R.id.full_name);
        userName=findViewById(R.id.user_name);
        email=findViewById(R.id.email);
        phone=findViewById(R.id.phone);
         setData(sharedPreference.readUserFromPreference());
    }
    public void setData(String loged ){
        Cursor cursor=databaseHelper.getLogedUser(loged);
        cursor.moveToFirst();
        fullName.setText(cursor.getString(0));
        userName.setText(cursor.getString(1));
        email.setText(cursor.getString(2));
        phone.setText(cursor.getString(4));
    }


}
