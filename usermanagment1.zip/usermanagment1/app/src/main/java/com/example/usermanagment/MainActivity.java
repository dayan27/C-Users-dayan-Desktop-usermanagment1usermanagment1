package com.example.usermanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import com.example.usermanagment.R;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    SharedPreference sharedPreference;

    TextView fullname,userName,email,phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      dbHelper =new DatabaseHelper(this);

      fullname =findViewById(R.id.full_name);
    userName=findViewById(R.id.user_name);
    email=findViewById(R.id.email);
    phone=findViewById(R.id.phone);
    Intent intent=getIntent();
    int pos=intent.getIntExtra("POSITION",1);

    setData(pos);

    }

    public void setData(int position){
        Cursor cursor= dbHelper.getAll();
        cursor.moveToPosition(position);
        fullname.setText(cursor.getString(0));
        userName.setText(cursor.getString(1));
        email.setText(cursor.getString(2));
        phone.setText(cursor.getString(4));
    }
}
